package com.unipi.telis.slide99;

//execution of slide 99
public class MyClass {
    //simple example of varargs
    public static void varargTest1(String...arguments){
        for(String s : arguments){
            System.out.println(s);
        }
    }
    //can be any type and name
    public static void varargTest2(int...helloWorld){
        for(int i : helloWorld){
            System.out.println(i);
        }
    }

    //there can only be one vararg in a method

    //public static void varargTest3(float...args1,short...args2){} this is impossible

    //the vararg MUST be the LAST argument
    public static void dataChange(String s,char c,int...args){
        int sum=0;
        for (int i=0;i<args.length;i++){
            sum+=args[i];
        }
        System.out.println(c+" "+sum+" "+s);
    }

    //this is   IMPOSSIBLE
    /*
    public static void dataChange1(String s,int...args,char c){   //Error: varargs parameter must be the last parameter !!!!!
        int sum=0;
        for (int i=0;i<args.length;i++){
            sum+=args[i];
        }
        System.out.println(c+" "+sum+" "+s);
    }
    */
    // after it would be imposible to pass values to it ! makes sense !


    public static void main(String[] args){
        varargTest1("Frodo","Sam","Aragon","Legolas","Gimli","Boromir");
        varargTest2(3,24,124,124,22,22,3333);
        //can have any amount of arguments
        varargTest2(3,24,124,124,22,22,3333,56,46589,65465,6545);
        varargTest2(3);
        varargTest2(54,25,176);
        dataChange("Telis",'A',12,13,16,15,14,18);

    }
}
