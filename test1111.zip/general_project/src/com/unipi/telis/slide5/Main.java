package com.unipi.telis.slide5;

//execution of slide 5
public class Main {
    public static void main(String[] args){

        Human h1 = new Human(15,"John","man");      //we just created an object of the class 'Human'
        h1.walk();  //object has methods
        h1.weigth=5;    //object has values
        System.out.println(h1.weigth);  //object methods can be called
        h1.speak("Good day today!");
        h1.introduction();
        //h1.run(); cant acces this! its private
        System.out.println(h1.toString());  //object also has methods of class Object !

    }
}
