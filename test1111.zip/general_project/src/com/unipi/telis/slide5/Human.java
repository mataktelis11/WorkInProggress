package com.unipi.telis.slide5;

//this is a class
public class Human {
    //these are fields
    private int age;
    private String name;
    private String gender;
    public int weigth;

    //we give the name , age and gender of the person when we 'create him'
    public Human(int age, String name, String gender) {
        this.age = age;
        this.name = name;
        this.gender = gender;
        System.out.println("Human created successfully");
    }

    //these are methods
    //they belong to each person 'created'
    public void walk(){
        System.out.println("I am walking");
    }
    public void speak(String word){
        System.out.println("I say "+word);
    }
    private void run(){
        System.out.println("I am running!!!");
    }
    public void introduction(){
        System.out.println("Hello! My name is "+this.name+". I am "+this.age+" years old and Im a "+this.gender);
        walk(); //object has access to its methods
        run();  //this is a private method only object can access it
    }
}
