package com.unipi.telis.slide161;

//execution of slide 161

public class Teacher {
    //fields
    String name;
    int officeNumber;
    int yearsOfService;
    boolean hasDegree;

    //constructor
    public Teacher(){
        System.out.println("A teacher was created!");
    }

    //method
    public void teach(){
        System.out.println("I am a teacher and i teach");
    }
}

class MathTeacher extends Teacher{

    String[] fibonacciNumbers;
    void solveProblems(){
        System.out.println("Applying formulas and solving");
    }
}

class BiologyTeacher extends Teacher{

    int dnaSamples;
    void useMicroscope(){
        System.out.println("I can see a new living organism");
    }
}


class Main{
    public static void main(String args[]){
        Teacher teacher = new Teacher();
        MathTeacher mathTeacher = new MathTeacher();
        BiologyTeacher biologyTeacher = new BiologyTeacher();       //notice that both mathTeacher and biologyTeacher ARE teachers (IS A Teacher)

        //IS A VS HAS A example (code is below):
        MSX msx = new MSX();
        msx.setModel("A599");
        msx.setMaxClock(500);
        msx.computerOverview();
        msx.msxPrintHelloWorld();
    }
}


// IS A   VS    HAS A

class Computer {
    //all these are instance members
    private String model;
    private int maxClock;
    void computerOverview(){
        System.out.println("Computer Model= "+model+" MaxClock= "+maxClock);
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setMaxClock(int maxClock) {
        this.maxClock = maxClock;
    }
}
class GraphicsCard {
    void initializeRender(){
        System.out.println("Processing output");
    }
    void display(){
        System.out.println("Print on screen : Hello World");
    }
}

class MSX extends Computer{

    //MSX extends Computer os it IS a Computer and inherits all its methods (apart from static and final)
    //MSX can also have additional functionality as the slide says
    void msxPrintHelloWorld(){
        GraphicsCard graphicsCard = new GraphicsCard();     //relationship of GraphicsCard class and MSX class is HAS A
        graphicsCard.initializeRender();                    //MSX has a graphics card!!!
        graphicsCard.display();
    }
}

