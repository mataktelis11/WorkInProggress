package com.unipi.telis.slide41;

//execution of slide 41
//as we can see we have a java file with one top-level public interface and we have more interfaces and classes as before


class Main2{
    public static void main(String[] args){
        Computer c = new Computer();
        c.print();
        c.act();
    }
}

class Computer implements MyInterface{
    @Override
    public void print() {
        System.out.println("Hello world");
    }

    @Override
    public void act() {
        System.out.println("Commodore 64 reading disk");
    }
}


//this is a top level and public interface
public interface MyInterface {
    public void print();
    public void act();
}

class Memory{
    int size;
}

/*
public interface T2 {           <<<----- impossible each file has ONE interface that is TOP-level AND public!
    public void print();
    public void act();
}
*/