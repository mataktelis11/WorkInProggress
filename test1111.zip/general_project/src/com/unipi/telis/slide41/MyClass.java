package com.unipi.telis.slide41;


//execution of slide 41
//as we can see we have a java file with one top-level public class that has various classes and interfaces in random order and its okay (for the compiler)
class Student extends Human implements ISpeak{
    @Override
    public void speak() {
        System.out.println("Hello im a Student");
    }

    int am;
}

abstract class Human{
    int age;
    String name;
}

class Teacher extends Human implements ITeach{
    @Override
    public void teach() {
        System.out.println("I am a Teacher and i teach");
    }

    String lesson;
}

//this is a top level class and public as well
public class MyClass {
    public void myMethod() {
        System.out.println("Hello from top-level public class MyClass");
    }
}
/*
public class Student{              <<<----- impossible each file has ONE class that is TOP-level AND public!
    public void print(){
        System.out.println("Hello from Student");
    }
}
*/

/*
public interface I1{        <<<--same thing with interfaces
    public void sayHello();
}
*/

//NOTE  a .java file can have either a) one top-level+publc class    or  b) one top-level+publc interface
//generally the name of the file matches the name of that class/interface so it wound make no sence to have more than one

interface ITeach{
    public void teach();
}


class Main{
    public static void main(String[] args){
        MyClass obj1 = new MyClass();
        obj1.myMethod();
        Student s = new Student();
        s.speak();
        Teacher t = new Teacher();
        t.teach();
    }
}

interface ISpeak{
    public void speak();
}