package com.unipi.telis.slide144;

//execution of slide 144

enum Species {
    MAMMAL,
    REPTILE,
    BIRD,
    AMPHIBIAN
}

public class Main {
    public static void main(String... args){
        //switch statement
        //switch statement works with byte , short , char and int (primitives)
        //example with int
        int grade =4;
        switch (grade) {
            case 5:
                System.out.println("You passed");
                break;
            case 6:
                System.out.println("You passed - you can do better");
                break;
            case 7:
                System.out.println("Good!");
                break;
            case 8:
                System.out.println("Very good!");
                break;
            case 9:
                System.out.println("Excellent!");
                break;
            case 10:
                System.out.println("Excellent");
                break;
            default:
                System.out.println("You didnt pass!");
        }

        //example with char
        char reportCard='F';
        switch (reportCard){
            case 'A':
                System.out.println("Excellent!");
                break;
            case 'B':
                System.out.println("Good!");
                break;
            case 'C':
                System.out.println("Average");
                break;
            case 'F':
                System.out.println("Bad!!!");
                break;
            default:
                System.out.println("Either its lower than F or the char is invalid (i hope)");
        }


        //switch statement also works with enums
        //example with enum
        Species myAnimal = Species.BIRD;
        switch (myAnimal){
            case MAMMAL:
                System.out.println("The animal is a Mammal");
                break;
            case REPTILE:
                System.out.println("The animal is a Reptile");
                break;
            case BIRD:
                System.out.println("The animal is a Bird");
                break;
            case AMPHIBIAN:
                System.out.println("The animal is a Amphibian");
                break;
            //no need for default enum takes only these values
        }



        //switch statement also works with Character, Byte, Short, and Integer (wrappers)
        //example with Byte and Break
        //notce unlike the previous example we do not have break in the end of every case
        //which means the code will keep moving to the next case untill there is a break or the switch finishes
        Byte score =8;
        char result;
        switch (score){
            case 6:result ='E';
            case 7:result ='D';
            case 8:result ='C';     //<--stated here
            case 9:result ='B';     //went here
            case 10:result ='A';    //went here
            default: result ='F';   //and here
        }
        //so the result is F !
        System.out.println(result);



        //and switch statement also works with Strings!!!
        //example with String
        String day = "Thursday";
        int dayNumber=0;
        switch (day.toLowerCase()){ //little trick: make the letters of the day lower so the input can be more generic
            case "monday":
                dayNumber = 1;
                break;
            case "tuesday":
                dayNumber = 2;
                break;
            case "wednesday":
                dayNumber = 3;
                break;
            case "thursday":
                dayNumber = 4;
                break;
            case "friday":
                dayNumber = 5;
                break;
            case "saturday":
                dayNumber = 6;
                break;
            case "sunday":
                dayNumber = 7;
                break;
            default:
                System.out.println("this is an invalid day");
        }

        System.out.println(dayNumber);

        //NOTE we can assign multiple cases to the same code:
        int num=6;
        switch (num){
            case 1: case 3: case 5: case 7:
                System.out.println("num is a prime number");
                break;
            case 2: case 4: case 6: case 8: case 9: case 10:
                System.out.println("num is not a prime number");
                break;
            default:
                System.out.println("num is must be in range [1,10]");
                break;
        }


    }
}
