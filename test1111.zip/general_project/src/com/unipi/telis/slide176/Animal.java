package com.unipi.telis.slide176;

//execution of slide 176

public class Animal {
    String category;
    String name;
    int averageAge;
    int averageWeight;
    public void move(){
        System.out.println("Most animals can move");
    }
}

interface IEat {
    void eat(String s);
}

class Cat extends Animal implements IEat{

    int numberOfClaws;

    public void meow(){
        System.out.println("MEEEOOOWWW!!!!");
    }

    @Override
    public void eat(String s) {
        System.out.println("I am a Cat and i eat "+s);
    }
}

class Dog extends Animal implements IEat{

    int age;

    public void bark(){
        System.out.println("Woof!! Woof!!");
    }

    @Override
    public void eat(String s) {
        System.out.println("I am a Dog and i eat "+s);
    }
}

class Main {
    public static void main(String[] args){

    }
}