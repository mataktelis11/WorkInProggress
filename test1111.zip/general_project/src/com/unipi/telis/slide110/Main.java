package com.unipi.telis.slide110;

//execution of slide 110
public class Main {
    //overloaded methods MUST have different parameters

    //this means:
    //different number of parameters:
    public static int add(int a){
        int i = a + 1;
        return 0;
    }
    public static int add(int a,int b){
        int i = a + b;
        return 0;
    }

    //or different type of parameters:
    public static void sub(int i){
        int result = i -1;
    }
    public static void sub(float f){
        float result = f - 0.5f;
    }

    //or both:
    public static void mul(int i1,int i2){
        int a = i1 * i2;
    }
    public static void mul(float f1,float f2,long l){
        float b = f1 * f2 ;
    }

    //overloaded methods can also have different sequence of parameters // it is not recommended - it may confuse us
    public static void print(String s,int i){
        System.out.println("Overload 1 of method print");
    }
    public static void print(int i,String s){
        System.out.println("Overload 2 of method print");
    }





    //in overloaded methods return type doesnt count !!!

    //this is wrong:
//    public void sayHello(String s){
//        System.out.println("Overload 1 Hello World");
//    }
//
//    public int sayHello(String s){
//        System.out.println("Overload 2 Hello World");
//        return 0;
//    }

    //overloaded methods may or may not have different return types
    public int sayHello(String s){
        System.out.println("Overload 1 Hello World");
        return 0;
    }
    public void sayHello(int i){
        System.out.println("Overload 2 Hello World");
    }
    public int sayHello(boolean b){
        System.out.println("Overload 3 Hello World");
        return 0;
    }
    public void sayHello(char c){
        System.out.println("Overload 4 Hello World");
    }

    //overloaded methods may or may not have different access modifiers
    public int copy(String name){
        System.out.println("Overload 1 copy");
        return 0;
    }
    private void copy(float num){
        System.out.println("Overload 2 copy");
    }
    int copy(Object o){
        System.out.println("Overload 3 copy");
        return 0;
    }
    protected void copy(boolean b){
        System.out.println("Overload 4 copy");
    }

    //overloaded methods cannot be defined access modifiers
    //this is WRONG:
   /* public boolean isHuman(Object o){
        return false;
    }
    private boolean isHuman(Object o){
        return false;
    }*/

    //or by different return type
    //this is WRONG:
    /*void myMethod(){
        System.out.println("Hello world");
    }
    String myMethod(){
        return "Hello world";
    }
    */

    //or both
    //this is WRONG:
    /*
    public int testMethod(){
        return 0;
    }
    private void testMethod(){
       System.out.println("Test");
    }
     */

    public static void main (String[] args){
        print("abc",10);
        print(111,"ggg");
        Main m = new Main();
        m.sayHello("Hi");
        m.sayHello(2);
        m.sayHello(false);
        m.sayHello('T');
        m.copy("Telis");
        m.copy(0.14f);
        Object o = new Object();
        m.copy(o);
        m.copy(true);


    }

}
