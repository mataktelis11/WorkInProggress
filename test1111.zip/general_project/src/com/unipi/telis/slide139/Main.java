package com.unipi.telis.slide139;

//execution of slide 139
public class Main {

    //ternary operator as max method
    static int max(int i1,int i2){
        int max = i1 >= i2 ? i1 : i2 ;  //(if (i1 >= i2) return i1 else return i2 )
        return max;
    }

    //ternary operator as min method
    static int min(int i1,int i2){
        return i1 <= i2 ? i1 : i2;
    }

    //ternary operator as absolute value (abs) method
    static int abs(int i){
        return i >= 0 ? i : -i;
    }


    public static void main(String... args){
        System.out.println(max(30,40));
        System.out.println(min(12,-7));
        System.out.println(abs(123));
        System.out.println(abs(0));
        System.out.println(abs(-70));

        //Syntax of ternary operator :
        //condition ? value_if_true : value_if_false

        String s1 = false ? "Condition is true" : "Condition is false";
        String s2 = true ? "Condition is true" : "Condition is false";
        System.out.println(s1+"\n"+s2);
    }
}
