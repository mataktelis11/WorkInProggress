package com.unipi.telis.slide104;

//execution of slide 104
public class Main {
    public static void main(String[] args){
        Worker worker = new Worker();
        Builder builder = new Builder();
        builder.buid();
        builder.sayHello();
        Student student = new Student("e",12);

    }
}
class Worker{
    //fields (non-static/instance)
    String name;
    int address;
    static int id;  //static variable!

    public void sayHello(){
        System.out.println("Hello world");
    }

    public static void showId(){
        System.out.println(id);
    }

    public void print(String s){
        System.out.println(s);
    }

    public void changer(){
        this.address =  000;    //'this' grands access to the members of the current class
        this.name = "Bob";      //both instance

        this.id = 111;          //and static
        //and also methods
        this.sayHello();    //non-static
        this.showId();      //and static

    }

    public void action(){
        print(this.name);   //keyword 'this' can also help to use the members as parameters
        int address=23;
        this.address = address ;    //and to differentiate members
    }



}

class Builder extends Worker{
    public void buid(){
        //super gives access to the members of the superclass we are in
        super.address = 5;      //access to instance members
        super.name = "Jimmy";
        super.sayHello();   //also includes methods
        System.out.println(super.id);   //also includes static members
        super.showId();         //and static methods

        //super can also be used to enhance a method of the parent-class
    }

    @Override
    public void sayHello() {
        super.sayHello();   //we call the sayHello method of the parentclass
        System.out.println("I am a method of the Child Class!!!");  //we add more code
    }
    //this way we keep what the method already had and we and things to it (we dont copy paste!!)

}

//we can use this and super in constructors!!!
class Human{
    //instance variables
    String name;
    int age;

    //constructors
    public Human(String name) {
        this.name = name;
        System.out.println("Called first constructor of class Human");
    }
    public Human(String name, int age) {
        //int i = 0; //Error: call to 'this' must be first statement in constructor
        this(name);     //this calls the constructor of the currenct class that accepts only one parameter String (name)
        this.age = age;
        System.out.println("Called second constructor of class Human");
    }
}
class Student extends Human{
    Student(String name, int age){
        //int i =0; //cannot have code above the super in constructor
        super(name, age);   //this calls the constructor of the superclass that accepts only 2 parameters
        System.out.println("Called constructor of class Student");
    }
}

//here is a classs