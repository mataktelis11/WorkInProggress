package com.unipi.telis;


//A.M. : P19100
//Onomateponumo : Aristotelis Matakias

public class Main {

    public static void main(String[] args) {
	    System.out.println("Welcome!\nThis is a project that contains examples for java!\nA.M. : P19100\nOnomateponumo : Aristotelis Matakias  ");

    }
}
