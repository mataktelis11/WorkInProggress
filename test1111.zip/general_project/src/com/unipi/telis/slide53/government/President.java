package com.unipi.telis.slide53.government;

//execution of slide 53 part 1

import static com.unipi.telis.slide53.authorization.Paper.size;     //this is the import static statement
//static import com.unipi.telis.slide53.authorization.Paper.size;   //correctly is 'import static' and NOT static import
public class President {
    //constructor
    public President() {
        size =100;  //can access static variable size
    }
}
