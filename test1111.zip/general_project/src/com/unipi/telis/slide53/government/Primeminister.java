package com.unipi.telis.slide53.government;

//execution of slide 53 part 2

import static com.unipi.telis.slide53.authorization.Paper.*;    //look at this! this way we have access to all static fields + methods
public class Primeminister {
    //constructor
    public Primeminister() {
        size=5;
        print();
        //name="Akis";  //however name is static but it is not public!!!! so we cant access it!!!!
    }
    static public void main(String[] args){
        Primeminister primeminister = new Primeminister();
    }
}
