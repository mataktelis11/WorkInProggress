package com.unipi.telis.slide53.authorization;

public class Paper {
    //fields
    public static int size;        //static + public
    static String name;            //static
    char c;                        //non-static

    //static + public method
    public static void print(){
        System.out.println("Paper size is "+Paper.size+" and paper name is "+Paper.name);
    }

    //non-static method
    void delete(){
        System.out.println("Paper will be deleted");
    }
}
