package com.unipi.telis.slide98;

//execution of slide 98
public class MyClass {

    //this is a method of type int so it MUST return an int

    /*
    public int myMethod1(int var1,int var2){        //Error: java: missing return statement!!!!!!!!!!!!!
        int i = var1 + var2 ;
    }
    */
    public int add(int var1,int var2){
        int i = var1 + var2 ;

       // return // also wrong . If the method returns a value then return must be followed immediately by a value!!!!!!
        return i;   //returns the int 'i'
    }


    //this is a method of type void so it returns void
    //it doesnt need to have the return statement
    public void myMethod1(){
        System.out.println("Hello from void method");
    }

    //it can have a return statement but it MUST NOT BE followed by any value !!!!!
    public void myMethod2(){
        System.out.println("Hello from another void method");

        //return true; NO can only be like this:
        return;
    }

    //lookout!! the return statement immediately exits the code from the method
    // so if there is more code after the return statement it can become unreachable and if it is obvious the compiler will give an error!

    //here the compiler will say Error: unreachable statement / the code is Unreachable
//    public void myMethod3(){
//        int i=0;
//        i+=1;
//        return;
//        i+=2;
//        System.out.println("Ended");
//    }


    //the compiler will not recognize this but it is still Unreachable!!
    public void myMethod4(){
        int i=0;
        i+=1;
        if (true){      // this is another usage of return statement via 'if'
            System.out.println("Ended with return");
            return;
        }
        i+=2;   //Unreachable!!
        System.out.println("Ended"); //Unreachable!!!
    }


    //clever use of the power of return!!
    //this method seachers the given array to find the number 10
    public void findNumber(int a[]){
        //foreach
        for(int num:a){
            if (num==10){
                System.out.println("found 10");
                return;}//as soon as it finds 10 exits the method
        }
        System.out.println("didnt find 10");
    }

    //this is especially useful in nested loops
    public int myLoops1(){
        for(int k=0;k<1000;k++) {
            for (int i = 0; i < 100; i++) {
                for (int j = 0; j < 10; j++) {
                    if (k==3 && i == 4 && j == 5)
                        return k;

                }
            }
        }
        return 1;//if it returns 1 then lets say that something went wrong
    }


    //also in unending loops
    public int myLoops2(){
        int i=0;
        while(true){
            i+=1;
            if(i==100){
                return i;
            }
        }
    }


    public static void main(String[] args){
        MyClass myClass = new MyClass();
        System.out.println(myClass.add(3,5));
        myClass.myMethod1();
        myClass.myMethod2();
        myClass.myMethod4();
        int a[]={12,213,1232,231,32,10,23,1,3,4,2,5,2,4};
        myClass.findNumber(a);  //returned
        int b[]={4,42,12,32,243};
        myClass.findNumber(b);  //didnt find 10
        System.out.println(myClass.myLoops1());
        System.out.println(myClass.myLoops2());
    }
}
