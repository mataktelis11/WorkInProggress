package com.unipi.telis.slide100;

//execution of slide 100
public class Human {
    String name;
    int age;
}

interface ISpeak{
    void speak();
}

interface IStudy{
    void study();
}

interface ITeach{
    void teach();
}

class Student extends Human implements ISpeak,IStudy{

    int am;

    @Override
    public void speak() {
        System.out.println("I am a student and i can speak");
    }

    @Override
    public void study() {
        System.out.println("i am a student and i can study");
    }
}

class Professor extends Human implements ISpeak,ITeach{

    int officeNumber;

    @Override
    public void speak() {
        System.out.println("I am a professor and i can speak");
    }

    @Override
    public void teach() {
        System.out.println("I am a professor and i can teach");
    }
}

class Helper extends Professor{

    int yearsOfService;

}

class Dog {
    String name;
}

class Main{
    static public void main(String[] args){
        Human human = new Human();
        Student student = new Student();
        Professor professor = new Professor();
        Helper helper = new Helper();
        Dog dog = new Dog();

        //the instanceof operator is 'of boolean type' (true or false)
        // used on objects like this : (object) instanceof (type)
        System.out.println(human instanceof Human); //is human an object of type Human? Yes-True
        System.out.println(professor instanceof Human);    //true!! professor extends from Human so he is a Human!

        //Helper is a child of Professor. He inherits the methods Professor gets from the interfaces he implements
        helper.speak();
        helper.teach();
        System.out.println(helper instanceof Helper);       //true - obviously helper is of type Helper
        System.out.println(helper instanceof Professor);    //true - Helper is a child of Professor
        System.out.println(helper instanceof Human);        //true - Professor is a child of Human SO   Helper IS A Human

        System.out.println(helper instanceof ITeach);       //True!! - so Helper does implement ITeach
        System.out.println(helper instanceof ISpeak);       //True!! - so Helper does implement ISpeak


        //also includes interfaces:
        System.out.println(student instanceof IStudy);  //true. student can study   he implements IStudy interface!
        System.out.println(student instanceof ITeach);  //false. student cant teach  he DOES NOT implement ITeach interface!!!

        //we use instanceof to check if we can do Casting with objects
        if(student instanceof Human){   //we check if there is inheritance . only then we can cast
            Human h = (Human)student;   //this is casting with objects !! from Student to Human
        }
        //we if dont check we may get error!!
        //Professor p = (Professor)dog;

        //if(dog instanceof Human){}  ATTENTION dont use instanceof with irrelevant classes like this! it will always be false
        //and the compiler will give an error!!

        //downcasting with instanceof
        //Student s =(Student)new Human();  <--this will compile BUT we get ClassCastException
        //using instanceof:
        Human h = new Student();
        if(h instanceof Student){
            Student s = (Student)h;     //downcasting
            System.out.println("Downcast: Human -> Student");
        }

        //here is another gimmick:
        System.out.println(professor instanceof Object);    //true WE KNOW WHY : all classes inherit from Object class!!!
    }

}
