package com.unipi.telis.slide13;

//execution of slide 13
public class Main {
    public static void main(String...args){
        //Variable types in java

        //Primitive data types:
        //Numeric -> Signed -> Integers
        int i = -34;
        short s = 23;
        long l = -2000;

        //Numeric -> Signed -> Floating-point
        float f = 23.23f;
        double d = 3.14d;

        //Boolean
        boolean b = false;

        //ATTENTION

        //char c ="D";  NO :Error String cannot be converted to char !!!!!!
        char c1;
        c1='D';
        char c2 = 'F';

        String s1 = "DA";
        String s2;
        s2 = "FF";
        //String s3 = 'G';   <- does not compile as well !
    }
}
