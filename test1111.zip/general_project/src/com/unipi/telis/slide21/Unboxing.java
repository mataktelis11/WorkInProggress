package com.unipi.telis.slide21;

public class Unboxing {

    public static int add(int i){
        return i+1;
    }

    public static void main(String... args){
        //  --> UNBOXING <--
        //from wrapper type to primitive type
        //e.g. : Integer --- > int   (also done by hte compiler itself !)

        //there are two cases when Unboxing happens according to java

        //case 1: when a wrapper type object is passed as a parameter to a method that expects a primitive type.
        Integer i = 10;     //instantiate an Integer-type obj
        System.out.println(add(i));     //pass it to the method //prints 11
        //i was unboxed!
        System.out.println(add(Integer.valueOf(122)));  //of course works with anonumous objct

        //System.out.println(add(Long.valueOf(122)));   ATTENTION :Long cannot be converted to int!
        System.out.println(add(Byte.valueOf((byte) 12)));
        System.out.println(add(Short.valueOf((short) 15))); // can be done with Short and Byte but first had to cast. Intersting!


        //case 2: when a wrapper type object is assigned to a corresponding primitive type
        Long l = Long.valueOf(212312312);   //instantiate an Long-type obj
        long var1 = l;
        System.out.println(var1);       //simple

        //int var2 = l;   // cannot be done!

        float f1 = Float.valueOf(23.23f); //example with anonumous (again)
        double d1 = Float.valueOf(23.23f);  //ok

        //so it seems that we cannot do 'down casting' but we can do 'up casting'

    }


}
