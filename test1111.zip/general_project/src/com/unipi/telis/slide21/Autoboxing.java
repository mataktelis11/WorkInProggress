package com.unipi.telis.slide21;
import java.util.ArrayList;
import java.util.List;

//execution of slide 21
public class Autoboxing {

    public static void sub(Integer i){
        System.out.println(i-1);
    }

    public static void main(String... args){
        //  --> AUTOBOXING <--
        //from primitivee type to wrapper type
        //e.g. : int --- > Integer   (done by hte compiler itself !)

        //a good example is with a List of  Integers!
        List<Integer> myList = new ArrayList<>();
        for(int i =0;i<6 ;i++){
            myList.add(i);      //  we are adding i ,which is 'int' , while the List is of type 'Integer'
        }
        //yet the compiler doesnt complain and actually creates an 'Integer' object from i and adds that object to the List

        //this is what the compiler actually does:
        List<Integer> myList2 = new ArrayList<>();
        for(int i =0;i<6 ;i++){
            myList.add(Integer.valueOf(i));      //  as we know this is an anonymous object! nice
        }

        //display myList1
        for(Integer number : myList){
            System.out.println(number);     // prints 0 1 . . . 5
        }

        //display myList2
        for (Integer number: myList2) {
            System.out.println(number);
        }

        //generally there are two cases when Autoboxing happens according to java

        //case 1: when a primitive type is passed as a parameter to a method that expects an object of the corresponding wrapper class
        int u=13;
        sub(u); //yes! prints 12
        //float f=23f;
        //sub(f); not possible
        //long l=23;
        //sub(l);not possible
        //short s=12;
        //sub(s);

        //must be the corresponding type!

        //case 2:when a primitive type is assigned to a variable of the corresponding wrapper class

        Integer obj1;
        int num1=34;
        obj1=num1;
        System.out.println(obj1);//works
        long num2=121;
        //obj1=num2; again not possible
        short num3 = 23;
        //obj1=num3; again not possible

        //must be the corresponding primitive type type!

    }

}
