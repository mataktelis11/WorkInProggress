package com.unipi.telis.slide46.city;

//execution of slide 46 - part 1
public class Work {
    public static void main(String... args){
        //instantiating the Farm class from another package using the fully-qualified name
        com.unipi.telis.slide46.village.Farm farm = new com.unipi.telis.slide46.village.Farm("Mr Farmer",120);//notice : we must also use the fully-qualified name for the constructor as well!!!!
    }
}
