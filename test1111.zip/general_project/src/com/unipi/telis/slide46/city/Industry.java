package com.unipi.telis.slide46.city;

import com.unipi.telis.slide46.village.Farm;    //this is the import statement !!!

//execution of slide 46 - part 1
public class Industry {
    public static void main(String args[]){
        //instantiating the Farm class from another package using the import statement !!!
        Farm farm = new Farm("Uncle-John",500);
    }
}
