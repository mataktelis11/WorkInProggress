package com.unipi.telis.slide46.village;

public class Farm {
    String farmerName;
    int size;

    public Farm(String farmerName, int size) {
        this.farmerName = farmerName;
        this.size = size;
    }
}
