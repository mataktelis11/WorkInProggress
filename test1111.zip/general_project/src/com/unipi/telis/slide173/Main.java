package com.unipi.telis.slide173;

//execution of slide 173

// OVERRIDING METHODS

//we can override methods from the superclass
class Animal {
    //instance methods
    public void attack(){
        System.out.println("I am an Animal and i attack!");
    }
    int returnWeight(int i){
        return i;
    }

    //class method
    static void breed(){
        System.out.println("All Animals breed");
    }

}

class Tiger extends Animal {
    //we override methods by using the same name
    @Override   //and preferably this keyword
    public void attack() {
        System.out.println("I am a Tiger and i attack!");
    }
    //now we altered the attack() method to use as we want


    //if we did this instead:
    /*
    @Override
    protected void attack() {
        System.out.println("I am a Tiger and i attack!");
    }
    */

    //or this:
    /*
    @Override
    private void attack() {
        System.out.println("I am a Tiger and i attack!");
    }
    */
    //or this:
    /*
    @Override
    void attack() {
        System.out.println("I am a Tiger and i attack!");
    }
    */
    //we get compiler error :Tiger cannot override attack() attempting to assign weaker access privileges; was public

    //so it seems we can only 'expand the access level' and not limit it
    //so method returnWeight is protected can become public and default

    /*
    //public:
    @Override
    public int returnWeight(int i) {
        return super.returnWeight(i);
    }
    */


    //default:
    @Override
     int returnWeight(int i) {
        return super.returnWeight(i);
    }


    //and we cannot make it private:
    /*
    @Override
    private int returnWeight(int i) {
        return super.returnWeight(i);
    }
    */

    //what happens with static methods of the superclass? can we override them?
    /*
    @Override
    static void breed(){
        System.out.println("Tiger can breed");
    }
    */     //we get this error : static methods cannot be annotated with @Override
    //we can type it without the annotation
    static void breed(){
        System.out.println("Tiger can breed");
    }
    //the code actually runs as we may expect (see Main class below)
    //but we are not overriding!!!  the static member belongs to the class
    //this means that in this case we actually have 2 different methods that have the name 'breed'
    //Animal and Tiger have their OWN static members and they belong ONLY to them!!!!
    //static methods cannot be 'overrided'
}


//we can also override methods from the implemented interface (in this case we have to!!!)
interface ISpeak {
    public void speak(String s) ;

    public static void answer(String s){
        System.out.println("The answer is "+s);
    }
}

class Student implements ISpeak {
    //we cant do this, the same applies  as above
    //we get this error: attempting to assign weaker access privileges; was public
    /*
    @Override
     void speak(String s) {
        System.out.println("This Student says "+s);
    }
    */
    //correct:

    @Override
    public void speak(String s) {
        System.out.println("This Student says "+s);
    }
//    @Override   once again: error: static methods cannot be annotated with @Override
//    public static void answer(String s){
//        System.out.println("The answer is "+s);
//    }
    public static void answer(String s){        //and this is not an override but an entirely different method!
        System.out.println("The answer is "+s);
    }
}



public class Main {
    static public void main(String[] args){
        //overriding from the superclass
        Animal a = new Animal();
        Tiger t = new Tiger();
        a.attack();     //instance method of superclass
        t.attack();     //instance method of subclass

        System.out.println(a.returnWeight(133));    //instance method of superclass
        System.out.println(t.returnWeight(344));    //instance method of subclass

        a.breed();      //static method of superclass
        t.breed();      //static method of class Tiger

        Student s = new Student();
        s.speak("Good job!");   //instance method implemented
        s.answer("42");         //static method of class Student

    }
}

