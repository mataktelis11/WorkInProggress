package com.unipi.telis.slide111;

//execution of slide 111 part 2
public class Human {
    int age;
    String gender;
    String name;
    /*
    //this is the default constructor:
    Human(){
        super();    //calls the constructor of class Object that takes no parameters
    }
    */
    public Human(){
        System.out.println("A Human has been created"); //since we created a constructor the compiler will NOT create the default constructor
    }
}

class Professor extends Human{
    int classNumber;
    //constructors can take overloads as we already said
    //constructors also support all access modifiers
    //these are public constructors

    //no-argument constructor
    public Professor(){
        this(301,"Mathimatikos");   //with keyword 'this' we can access the constructor of the current class that accepts 2 arguments
    }

    //constructor that accepts 2 method arguments
    public Professor(int classNumber,String name) {
        this.classNumber = classNumber;
        this.name = name;
    }

    //default-access constructor
    Professor(String name){
        this.name = name;
    }
    //protected constructor
    //this is wrong :
//    protected Professor(){
//        System.out.println("A professor was created");
//    }
    //we cannot have overloaded constructors that ONLY defer in the access level just like overloaded methods

    protected Professor(int i1,int i2){
        //System.out.println("A professor was created from protected constructor");
        //this(102); call to 'this' must be first statement in constructor !!!
        this(102);//calling private constructor
        System.out.println("A professor was created from protected constructor");
       // this(301,"Mathimatikos"); a constructor can only call one other constructor( of the same class)
    }

    //private constructor //we can only call it from within the class
    private Professor(int classNumber){
        System.out.println("A professor was created from private constructor");
    }

    public void call(){
        //this(103); we cannot call a constructor like this in a method
        //we must do it normally with the keyword 'new'
        Professor p =new Professor(192); // we are in the class so we can access the private constructor
    }
}

class Main {
    public static void main(String[] args){
        Human h = new Human();
        Professor p1 =new Professor();
        Professor p2 =new Professor(302,"DrSeferlis");
        Professor p3 =new Professor(12,34);
        //Professor p4 =new Professor(4); we cannot access the private constructor from here!
        //notice that every time the constructor of the Human(mother class) is called
        p3.call();//calling a method
    }
}



