package com.unipi.telis.slide111;

//execution of slide 111 part 1
public class Student {
    String name;
    int age;
    int am;

    //this is a constructor
    public Student() {
        System.out.println("A student was created");
    }
    //constructors DO NOT RETURN ANYTHING NOT EVEN VOID
    //this is NOT a constructor it is a method!
    public void Student() {
        System.out.println("This is a method!");
    }

    //constructors can also have overloads
    //this is a very classic use of the constructor: it gives the initial values of an object
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }
    //again this is a method
    public void Student(int age, int am) {
        this.age = age;
        this.am = am;
    }

    public static void main (String[] args){
        Student s1 = new Student(); //called the constructor we created
        s1.Student();   //this is a method
        Student s2 = new Student("Telis",19);   //called the constructor thst takes a string and an int as parameters
        //Student s3 = new Student(20,20);//we cannot call this because its a method and  NOT a constructor
        s2.Student(20,20);  //it is just an overloaded method
        //NOTE : NEVER USE METHODS WITH THE SAME NAME AS THE CLASS !!!!!!!!!!!!!!
    }

}



