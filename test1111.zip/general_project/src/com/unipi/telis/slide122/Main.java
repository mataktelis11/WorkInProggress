package com.unipi.telis.slide122;

//execution of slide 122
public class Main {
    static public void main(String args[]){
        //Strings are VERY IMPORTANT
        //Strings are reference type variables
        //operator '==' is used to compare the addresses of reference types

        String str1 = "Commodore64";    //"Commodore64" is a new string so it is added to the string pool
        String str2 = "IBM PC";         //"IBM PC" will also go to the string pool
        String str3 = "Commodore64";    //"Commodore64" is already in the string pool so java will not create
                                        // a new String object in the pool and instead str3 will refer (point) to the existing string!

        //So this will print true:
        System.out.println(str1==str3);     //as we explained those two reference types point to the same string at the string pool
        //and this will print false:
        System.out.println(str1==str2);     //those do not!

        //we shouldnt(MUST NOT) compare Stings like this!!!
        //if we instantiate a String like this:

        String word1 = new String("MSDOS");
        String word2 = new String("Duke Nukem 3d");     // these strings ARE NOT IN THE STRING POOL
        String word3 = new String("MSDOS");
        String word4 = new String("IBM PC");

        //so these will print false:
        System.out.println(word1==word3);       //these reference types DO NOT POINT TO THE SAME STRING OBJECT!!
        System.out.println(word1==word2);

        //to compare the "true value" of a String we use the method equals()
        System.out.println(str1.equals(str3));      //true
        System.out.println(str1.equals(str2));      //false
        System.out.println(word1.equals(word3));    //true
        System.out.println(word1.equals(word2));    //false

        //and of course doesnt matter if one String is the pool and the other not
        System.out.println(word4.equals(str2)); //true
        System.out.println(word2.equals(str2)); //false
    }
}
