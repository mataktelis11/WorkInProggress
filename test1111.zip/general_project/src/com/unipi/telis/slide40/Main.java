package com.unipi.telis.slide40;
//execution of slide 40 (part 2) - inner class (non static - nested)

//we can have a local class which is either a simple inner class OR a method-local inner class
//case 1: inner class
class Outer{

    private int i = 12;
    //inner class
    class Inner{
        public void print(){
            System.out.println("Hello from inner class!");
            System.out.println("I have access to private fields of Outer class "+i);
        }

    }
}

//case 2: method-local inner class
class Outer2{

    //method of the outer class (non-static)
    public void myMethod(){
        //inner class
        class Inner2{
            public void print(){
                System.out.println("Hello from method-local inner class!");
            }
        }
        //instantiating and accessing the inner class
        Inner2 inner2 = new Inner2();
        inner2.print();
    }
}

//execution
public class Main {
    public static void main(String[] args){
        //case 1
        // instantiating the Outer class
        Outer outer = new Outer();
        // instantiating the Inner class
        Outer.Inner inner =  outer.new Inner();
        inner.print();

        //case 2
        // instantiating the Outer2 class and calling the method
        Outer2 outer2 = new Outer2();
        outer2.myMethod();
    }

}



//we can also have an inner anonymous class
class MyClass{
    public void action(){
        System.out.println("Hello from MyClass");
    }
}
class Outer3{
    public static void main(String[] args){
        MyClass inner3 = new MyClass(){
            @Override
            public void action() {
                System.out.println("Hello from inner Anonymous Class !!!");
            }
        };inner3.action();
    }

}




