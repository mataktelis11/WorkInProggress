package com.unipi.telis.slide40;
//execution of slide 40 (part 1) - inner static class

//Animal is a top-level class (also public)
public class Animal {
    public int weigth;
    public int age;
    public String name;
    static int dna = 42;

    static void print(){
        System.out.println("dog is a animal");
    }

    //Dog is a nested class inside Animal that is also static!
    static class Dog {
        //note the static nested class can only access non-static members of the outer class
        public void smell(){
            System.out.println("Dog is sniffing the air "+dna);
            print();
        }
    }

    public static void main(String[] args){
        Animal.Dog d = new Animal.Dog();
        d.smell();
    }
}
